.. cmhdoctest documentation master file, created by
   sphinx-quickstart on Sat Jan 27 22:44:08 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

``latexindent.pl`` documentation
======================================

.. toctree::
   :numbered: 3

   sec-introduction
   sec-demonstration
   sec-how-to-use
   sec-indent-config-and-settings
   sec-default-user-local
   sec-the-m-switch
   sec-conclusions-know-limitations
   references
   appendices
